                                       ===================================================
                                       |                  WinOwnership                   |
                                       |                                                 |
                                       |        Developed by Josh Cell Softwares         |
                                       |                                                 |
                                       |              joshcellsoftwares.com              |
                                       ===================================================

	WinOwnership is a handy tool to help you in the Windows files and directories, enabling and disabling the system file protection


About:

	WinOwnership will help you in the full take own with files and directories, removing and restoring the system file protection without brick or touch on it


Features:

	One click to make full access with the file
	Metro interface based on Windows 8 compatible with Windows XP
	One click to restore the default Windows file ACL Protection
	Not touch on default system ACL Protection, the file after undo will shows the same protection
	Full file access with an new file ACL Replacement
	Using an new ACL Backup / Restore patch technology
	Not use any core Windows Resource to patch the file
	The file isn't patched, only the protection area, can restore with an "Undo" click
	The user can rename the unprotected file if is being used, with an possible patch with other file
	Support for all files types
	Can work with Windows core files
	Can work with directories
	Can work with ACL protected files
	Multi threaded modules
	Fast and light interface
	Full ACL kernel lock / unlock
	Works with multi items
	Multi CRC hash check
	Full support for Windows 8


Compatibility:

	Windows 8
	Windows 7
	Windows Vista
	Windows XP Family
	Windows Server 2003 / 2008 / 2011 Family

     * All Editions / Versions, including x64 systems
     * Requires .NET Framework v4.0


Latest Hashes for WinOwnership v1.1.exe

	CRC32: B0C7C884
	MD5: CE0BFEA3176B55A2375FE19B6DDB28AB
	SHA-1: E64CB4B469727E6653015C65FAB01F74149AB63C





		"All work is done and needed in the future", Michel Oliveira - Developer of all Josh Cell Softwares projects


			Email for contact: support@joshcellsoftwares.com

			WebSite: http://www.joshcellsoftwares.com/

			All Forums Support: http://forums.mydigitallife.info/members/197238-Josh-Cell


					Copyright 2012 Josh Cell Softwares, All Rights Reserved




v1.1

- Added the "Double click to browse" function
- New interface based on Metro of Windows 8
- Added multi items support
- Fixed all bugs